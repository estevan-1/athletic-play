ATHLETIC PLAY v0.2 — Athletic Gym Dapa

CONTENIDO
index.html — portada, menú y juegos
app.js — funcionamiento y récords locales
questions.js — banco de preguntas editable (59 preguntas)
assets/logo.jpg — logo enviado
assets/gym1.jpg y gym2.jpg — fotos reales enviadas

PRUEBA
Abra index.html en un navegador o publique toda la carpeta en GitHub Pages o Cloudflare Pages. No suba solo index.html: los otros archivos son necesarios.

PUBLICACIÓN CON GITHUB PAGES
1. Cree un repositorio público nuevo (por ejemplo athletic-play).
2. Suba el CONTENIDO de esta carpeta a la raíz del repositorio (index.html, app.js, questions.js y carpeta assets).
3. En Settings > Pages > Build and deployment, elija Deploy from a branch, rama main, carpeta /(root), Save.
4. Espere a que GitHub muestre la dirección publicada y pruébela en Safari.

ADVERTENCIAS
El enlace anterior de Netlify NO se modifica al publicar esta carpeta.
Los récords se guardan en localStorage, solo en cada navegador. No son válidos para premios verificables.
No se recogen datos personales ni hay formulario/Excel o panel privado en esta versión.
Athletic Rush aparece como Próximamente, no es jugable aún.
No se han realizado pruebas automatizadas en Safari real.
